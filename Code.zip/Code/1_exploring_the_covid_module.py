
#from covid19_data import JHU


#Test1

##print("The number of recovered people in the US : " +str(JHU.US.recovered))
##print("The number of confirmed cases in the US : " +str(JHU.US.confirmed))
##
##print("The number of deaths in California state : " +str(JHU.California.deaths))
##
##print("The number of confirmed cases in the UK : " +str(JHU.UnitedKingdom.confirmed))

#Test 2

##import covid19_data as COVID
##
##
##total =  COVID.dataByName("Total")
##India =  COVID.dataByName("India")
##
##print("Total cases: " +str(total.cases))
##print("India cases : " + str(India.cases))
##
##
##print("Total confirmed: " +str(total.confirmed))
##print("India confirmed: " + str(India.confirmed))


#Test3
import covid19_data as COVID

total =  COVID.jsonByName("Total")
India =  COVID.jsonByName("India")



print("Total " +str(total))
print("India " + str(India))











